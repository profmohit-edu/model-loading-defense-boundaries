# Supplementary Material 1
Coverage boundaries of machine learning model loading defenses

This anonymous supplement provides 24 source-extraction records, references, discovery queries, four manuscript tables, DOI checks and all twelve benign NumPy policy probes. It contains no third-party full texts or malicious model artifacts. Source hashes identify the originally retrieved bytes; referenced source paths describe acquisition files and are not distributed here.

Reproduction: Python 3.12.14 and NumPy 2.3.5 were used. Install requirements.txt in an isolated Python environment, then run `python code/verify_supplement.py`. The verifier reruns trusted, locally generated numeric and object-array probes and checks all case outcomes against the recorded results. The fixtures contain integers, strings and None, with no custom callable. Only local temporary files are opened; no network or shell command is used by the probes.

The experiment is a fixed twelve-case illustration, not a random sample, exploit test, scanner benchmark or security proof. The review is purposive rather than an exhaustive systematic review. Source extraction and drafting were AI-assisted and not independently adjudicated. Interpretive source accuracy requires human review.
